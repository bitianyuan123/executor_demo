# 阶段3：指标质量与阈值均衡

读取 15 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|main-t16-local-queue-home / 32000 / evaluate|True|400/400|25.836|43.175|14.320|11.058|0.000|
|main-t16-local-home / 32000 / evaluate|True|400/400|25.707|43.021|14.351|11.152|0.000|
|main-t16-local-queue-h2 / 32000 / evaluate|True|400/400|13.776|24.464|6.082|7.157|0.475|
|main-t16-local-outstanding-h2 / 32000 / evaluate|True|400/400|13.994|23.468|6.162|7.122|0.492|
|main-t16-local-spread-policy / 32000 / evaluate|True|400/400|13.769|23.217|6.086|7.096|0.500|
|main-t16-local-outstanding-h2 / 32001 / evaluate|True|400/400|14.082|22.674|6.274|7.120|0.487|
|main-t16-local-home / 32001 / evaluate|True|400/400|25.761|42.756|14.359|11.164|0.000|
|main-t16-local-queue-home / 32001 / evaluate|True|400/400|26.044|45.649|14.498|11.100|0.000|
|main-t16-local-spread-policy / 32001 / evaluate|True|400/400|14.046|22.946|6.102|7.151|0.500|
|main-t16-local-queue-h2 / 32001 / evaluate|True|400/400|13.978|23.454|5.843|7.170|0.472|
|main-t16-local-queue-home / 32002 / evaluate|True|400/400|25.268|43.001|13.878|10.751|0.000|
|main-t16-local-home / 32002 / evaluate|True|400/400|25.580|43.089|14.016|11.050|0.000|
|main-t16-local-spread-policy / 32002 / evaluate|True|400/400|13.723|22.689|5.882|7.082|0.500|
|main-t16-local-outstanding-h2 / 32002 / evaluate|True|400/400|14.021|22.838|6.011|7.176|0.490|
|main-t16-local-queue-h2 / 32002 / evaluate|True|400/400|14.228|25.057|6.055|7.348|0.475|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
|main-t16-local-outstanding-h2 / evaluate|3/0|-11.650|-19.962|NA|descriptive_only|
|main-t16-local-spread-policy / evaluate|3/0|-11.837|-20.005|NA|descriptive_only|
|main-t16-local-queue-h2 / evaluate|3/0|-11.722|-19.617|NA|descriptive_only|

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
