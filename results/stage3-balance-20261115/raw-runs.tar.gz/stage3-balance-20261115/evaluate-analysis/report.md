# 阶段3：指标质量与阈值均衡

读取 28 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|main-t16-local-home / 31000 / evaluate|True|400/400|26.248|44.195|14.306|11.504|0.000|
|main-t16-local-outstanding-h2 / 31000 / evaluate|True|400/400|14.093|23.497|5.961|7.270|0.492|
|main-t16-local-queue-h2 / 31000 / evaluate|True|400/400|13.858|23.764|5.906|7.121|0.470|
|main-t16-local-spread-policy / 31000 / evaluate|True|400/400|14.440|24.324|6.164|7.377|0.500|
|main-t16-local-queue-h2 / 31001 / evaluate|True|400/400|14.029|23.875|6.081|7.259|0.465|
|main-t16-local-home / 31001 / evaluate|True|400/400|25.837|43.291|14.631|10.944|0.000|
|main-t16-local-outstanding-h2 / 31001 / evaluate|True|400/400|14.141|23.297|6.276|7.323|0.497|
|main-t16-local-spread-policy / 31001 / evaluate|True|400/400|14.239|23.013|6.183|7.358|0.500|
|main-t16-local-outstanding-h2 / 31002 / evaluate|True|400/400|14.036|23.578|5.768|7.180|0.485|
|main-t16-local-spread-policy / 31002 / evaluate|True|400/400|13.977|23.323|6.101|7.178|0.500|
|main-t16-local-home / 31002 / evaluate|True|400/400|25.515|43.636|14.179|10.840|0.000|
|main-t16-local-queue-h2 / 31002 / evaluate|True|400/400|13.969|23.926|5.773|7.176|0.472|
|main-t16-local-spread-policy / 31003 / evaluate|True|400/400|13.855|22.832|6.099|7.061|0.500|
|main-t16-local-queue-h2 / 31003 / evaluate|True|400/400|14.089|23.420|6.318|7.264|0.482|
|main-t16-local-home / 31003 / evaluate|True|400/400|25.997|43.217|14.419|10.970|0.000|
|main-t16-local-outstanding-h2 / 31003 / evaluate|True|400/400|14.155|23.630|6.248|7.226|0.495|
|main-t16-local-spread-policy / 31004 / evaluate|True|400/400|13.731|22.292|5.945|7.031|0.500|
|main-t16-local-outstanding-h2 / 31004 / evaluate|True|400/400|14.119|22.269|6.453|7.226|0.495|
|main-t16-local-queue-h2 / 31004 / evaluate|True|400/400|14.026|23.562|6.183|7.258|0.477|
|main-t16-local-home / 31004 / evaluate|True|400/400|25.518|41.710|13.966|11.332|0.000|
|main-t16-local-spread-policy / 31005 / evaluate|True|400/400|15.573|34.181|7.525|7.593|0.500|
|main-t16-local-queue-h2 / 31005 / evaluate|True|400/400|14.021|23.367|6.244|7.254|0.485|
|main-t16-local-home / 31005 / evaluate|True|400/400|25.840|42.736|14.447|11.066|0.000|
|main-t16-local-outstanding-h2 / 31005 / evaluate|True|400/400|14.173|22.867|6.260|7.248|0.492|
|main-t16-local-outstanding-h2 / 31006 / evaluate|True|400/400|14.065|23.052|6.223|7.326|0.492|
|main-t16-local-queue-h2 / 31006 / evaluate|True|400/400|14.217|25.970|5.879|7.275|0.465|
|main-t16-local-spread-policy / 31006 / evaluate|True|400/400|14.224|23.556|6.239|7.147|0.500|
|main-t16-local-home / 31006 / evaluate|True|400/400|25.378|44.699|14.046|10.902|0.000|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
|main-t16-local-outstanding-h2 / evaluate|7/0|-11.650|-20.185|[-20.763398571428574, -19.72229614285714]|paired_seed_bootstrap|
|main-t16-local-queue-h2 / evaluate|7/0|-11.732|-19.371|[-19.849956857142853, -18.82954471428571]|paired_seed_bootstrap|
|main-t16-local-spread-policy / evaluate|7/0|-11.471|-18.566|[-20.555757571428575, -15.14090357142857]|paired_seed_bootstrap|

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
