# 阶段3：指标质量与阈值均衡

读取 6 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|main-t16-local-home / 11000 / observe|True|400/400|25.535|44.185|14.085|11.067|0.000|
|main-t1-local-home / 11000 / observe|True|400/400|20.969|43.270|18.893|1.993|0.000|
|main-t1-local-home / 11001 / observe|True|400/400|20.688|42.289|18.623|1.984|0.000|
|main-t16-local-home / 11001 / observe|True|400/400|25.324|43.310|14.028|11.001|0.000|
|main-t1-local-home / 11002 / observe|True|400/400|21.238|42.624|19.155|2.000|0.000|
|main-t16-local-home / 11002 / observe|True|400/400|26.039|44.314|14.412|11.081|0.000|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
没有可比较的routing候选；观测阶段不产生均衡收益结论。

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|
|f2a58c173107 / burst_context_remaining|callback_ms|burst_context_remaining|3|0.510|0.011|0.9817|-0.445|
|f2a58c173107 / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|0.125|0.003|0.9758|-0.060|
|f2a58c173107 / burst_context_remaining|latency_ms|burst_context_remaining|3|2.041|0.062|0.9892|7.960|
|f2a58c173107 / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|2.978|0.090|0.9817|7.023|
|f2a58c173107 / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|2.042|0.062|0.9892|7.963|
|f2a58c173107 / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|2.979|0.090|0.9817|7.026|
|f2a58c173107 / burst_context_remaining|wait_ms|burst_context_remaining|3|1.980|0.060|0.9892|8.021|
|f2a58c173107 / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|2.978|0.091|0.9792|7.023|
|f2a58c173107 / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|0.513|0.011|0.9817|-0.448|
|f2a58c173107 / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|0.126|0.003|0.9725|-0.061|
|f2a58c173107 / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|2.001|0.063|0.9867|8.000|
|f2a58c173107 / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|2.937|0.094|0.9825|7.064|
|f2a58c173107 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|2.002|0.063|0.9867|8.003|
|f2a58c173107 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|2.938|0.094|0.9825|7.067|
|f2a58c173107 / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|1.929|0.058|0.9883|8.072|
|f2a58c173107 / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|2.931|0.095|0.9800|7.070|
|f2a58c173107 / queue|callback_ms|queue|3|0.513|0.011|0.9817|-0.448|
|f2a58c173107 / queue|callback_ms|queue+own_budget_oracle|3|0.126|0.003|0.9733|-0.061|
|f2a58c173107 / queue|latency_ms|queue|3|2.002|0.062|0.9858|7.999|
|f2a58c173107 / queue|latency_ms|queue+own_budget_oracle|3|2.934|0.094|0.9833|7.067|
|f2a58c173107 / queue|planned_latency_ms|queue|3|2.002|0.062|0.9858|8.002|
|f2a58c173107 / queue|planned_latency_ms|queue+own_budget_oracle|3|2.935|0.094|0.9833|7.070|
|f2a58c173107 / queue|wait_ms|queue|3|1.934|0.058|0.9875|8.067|
|f2a58c173107 / queue|wait_ms|queue+own_budget_oracle|3|2.929|0.095|0.9808|7.072|
|f2a58c173107 / queue_per_capacity|callback_ms|queue_per_capacity|3|0.513|0.011|0.9817|-0.448|
|f2a58c173107 / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|0.126|0.003|0.9733|-0.061|
|f2a58c173107 / queue_per_capacity|latency_ms|queue_per_capacity|3|2.002|0.062|0.9858|7.999|
|f2a58c173107 / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|2.934|0.094|0.9833|7.067|
|f2a58c173107 / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|2.002|0.062|0.9858|8.002|
|f2a58c173107 / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|2.935|0.094|0.9833|7.070|
|f2a58c173107 / queue_per_capacity|wait_ms|queue_per_capacity|3|1.934|0.058|0.9875|8.067|
|f2a58c173107 / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|2.929|0.095|0.9808|7.072|
|f2a58c173107 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|0.513|0.011|0.9817|-0.448|
|f2a58c173107 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.126|0.003|0.9725|-0.061|
|f2a58c173107 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|2.001|0.063|0.9867|8.000|
|f2a58c173107 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.937|0.094|0.9825|7.064|
|f2a58c173107 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|2.002|0.063|0.9867|8.003|
|f2a58c173107 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.938|0.094|0.9825|7.067|
|f2a58c173107 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|1.929|0.058|0.9883|8.072|
|f2a58c173107 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.931|0.095|0.9800|7.070|
|f2a58c173107 / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|0.513|0.011|0.9817|-0.448|
|f2a58c173107 / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|0.126|0.003|0.9725|-0.061|
|f2a58c173107 / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|2.001|0.063|0.9867|8.000|
|f2a58c173107 / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|2.937|0.094|0.9825|7.064|
|f2a58c173107 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|2.002|0.063|0.9867|8.003|
|f2a58c173107 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|2.938|0.094|0.9825|7.067|
|f2a58c173107 / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|1.929|0.058|0.9883|8.072|
|f2a58c173107 / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|2.931|0.095|0.9800|7.070|
|f395f5f21b08 / burst_context_remaining|callback_ms|burst_context_remaining|3|5.910|0.159|0.9867|-0.888|
|f395f5f21b08 / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|4.624|0.131|0.9800|0.398|
|f395f5f21b08 / burst_context_remaining|latency_ms|burst_context_remaining|3|6.286|0.182|0.9825|3.005|
|f395f5f21b08 / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|5.336|0.150|0.9858|3.955|
|f395f5f21b08 / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|6.304|0.186|0.9792|2.992|
|f395f5f21b08 / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|5.318|0.150|0.9833|3.977|
|f395f5f21b08 / burst_context_remaining|wait_ms|burst_context_remaining|3|1.880|0.062|0.9850|6.068|
|f395f5f21b08 / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|2.541|0.090|0.9783|5.406|
|f395f5f21b08 / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|5.872|0.161|0.9858|-0.851|
|f395f5f21b08 / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|4.656|0.135|0.9833|0.366|
|f395f5f21b08 / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|6.279|0.176|0.9875|3.012|
|f395f5f21b08 / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|5.274|0.145|0.9833|4.016|
|f395f5f21b08 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|6.282|0.174|0.9875|3.014|
|f395f5f21b08 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|5.255|0.149|0.9800|4.041|
|f395f5f21b08 / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|1.825|0.062|0.9850|6.122|
|f395f5f21b08 / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|2.463|0.091|0.9800|5.484|
|f395f5f21b08 / queue|callback_ms|queue|3|5.908|0.160|0.9867|-0.887|
|f395f5f21b08 / queue|callback_ms|queue+own_budget_oracle|3|4.660|0.129|0.9850|0.361|
|f395f5f21b08 / queue|latency_ms|queue|3|6.313|0.177|0.9875|2.977|
|f395f5f21b08 / queue|latency_ms|queue+own_budget_oracle|3|5.311|0.145|0.9842|3.979|
|f395f5f21b08 / queue|planned_latency_ms|queue|3|6.346|0.174|0.9875|2.949|
|f395f5f21b08 / queue|planned_latency_ms|queue+own_budget_oracle|3|5.313|0.148|0.9825|3.983|
|f395f5f21b08 / queue|wait_ms|queue|3|1.889|0.067|0.9842|6.058|
|f395f5f21b08 / queue|wait_ms|queue+own_budget_oracle|3|2.493|0.094|0.9792|5.455|
|f395f5f21b08 / queue_per_capacity|callback_ms|queue_per_capacity|3|5.908|0.160|0.9867|-0.887|
|f395f5f21b08 / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|4.660|0.129|0.9850|0.361|
|f395f5f21b08 / queue_per_capacity|latency_ms|queue_per_capacity|3|6.313|0.177|0.9875|2.977|
|f395f5f21b08 / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|5.311|0.145|0.9842|3.979|
|f395f5f21b08 / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|6.346|0.174|0.9875|2.949|
|f395f5f21b08 / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|5.313|0.148|0.9825|3.983|
|f395f5f21b08 / queue_per_capacity|wait_ms|queue_per_capacity|3|1.889|0.067|0.9842|6.058|
|f395f5f21b08 / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|2.493|0.094|0.9792|5.455|
|f395f5f21b08 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|5.889|0.159|0.9867|-0.867|
|f395f5f21b08 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|4.658|0.129|0.9850|0.364|
|f395f5f21b08 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|6.307|0.178|0.9875|2.983|
|f395f5f21b08 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|5.319|0.143|0.9833|3.972|
|f395f5f21b08 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|6.341|0.175|0.9875|2.955|
|f395f5f21b08 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|5.321|0.147|0.9817|3.974|
|f395f5f21b08 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|1.821|0.061|0.9850|6.126|
|f395f5f21b08 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.451|0.087|0.9800|5.496|
|f395f5f21b08 / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|5.872|0.161|0.9858|-0.851|
|f395f5f21b08 / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|4.656|0.135|0.9833|0.366|
|f395f5f21b08 / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|6.279|0.176|0.9875|3.012|
|f395f5f21b08 / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|5.274|0.145|0.9833|4.016|
|f395f5f21b08 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|6.282|0.174|0.9875|3.014|
|f395f5f21b08 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|5.255|0.149|0.9800|4.041|
|f395f5f21b08 / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|1.825|0.062|0.9850|6.122|
|f395f5f21b08 / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|2.463|0.091|0.9800|5.484|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|

检测到work与outstanding仅为同一信号的常数缩放：f2a58c173107, f395f5f21b08。这不构成两个独立指标发现。

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
