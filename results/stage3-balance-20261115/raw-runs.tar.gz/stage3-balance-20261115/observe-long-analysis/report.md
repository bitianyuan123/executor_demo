# 阶段3：指标质量与阈值均衡

读取 6 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|main-t16-local-home / 11000 / observe|True|120/120|310.269|420.633|67.474|242.713|0.000|
|main-t1-local-home / 11000 / observe|True|120/120|211.144|420.534|191.144|19.912|0.000|
|main-t1-local-home / 11001 / observe|True|120/120|203.760|400.919|183.999|19.673|0.000|
|main-t16-local-home / 11001 / observe|True|120/120|306.080|414.617|66.581|238.748|0.000|
|main-t1-local-home / 11002 / observe|True|120/120|211.496|423.441|191.367|20.044|0.000|
|main-t16-local-home / 11002 / observe|True|120/120|311.727|423.802|68.950|242.020|0.000|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
没有可比较的routing候选；观测阶段不产生均衡收益结论。

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|
|167276d9a69a / burst_context_remaining|callback_ms|burst_context_remaining|3|5.103|0.115|0.9667|-4.421|
|167276d9a69a / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|1.336|0.059|0.8972|-0.653|
|167276d9a69a / burst_context_remaining|latency_ms|burst_context_remaining|3|17.044|0.458|0.9750|85.136|
|167276d9a69a / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|27.591|1.252|0.9222|74.589|
|167276d9a69a / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|17.045|0.458|0.9750|85.139|
|167276d9a69a / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|27.592|1.251|0.9222|74.591|
|167276d9a69a / burst_context_remaining|wait_ms|burst_context_remaining|3|16.892|0.539|0.9722|85.196|
|167276d9a69a / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|27.505|1.240|0.9361|74.584|
|167276d9a69a / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|5.100|0.111|0.9722|-4.417|
|167276d9a69a / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|1.355|0.064|0.9028|-0.672|
|167276d9a69a / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|16.754|0.528|0.9694|85.425|
|167276d9a69a / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|28.098|1.075|0.9278|74.082|
|167276d9a69a / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|16.755|0.528|0.9694|85.428|
|167276d9a69a / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|28.099|1.074|0.9278|74.084|
|167276d9a69a / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|16.681|0.431|0.9778|85.408|
|167276d9a69a / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|28.018|1.047|0.9389|74.070|
|167276d9a69a / queue|callback_ms|queue|3|5.100|0.111|0.9722|-4.417|
|167276d9a69a / queue|callback_ms|queue+own_budget_oracle|3|1.355|0.064|0.9028|-0.672|
|167276d9a69a / queue|latency_ms|queue|3|16.754|0.528|0.9694|85.425|
|167276d9a69a / queue|latency_ms|queue+own_budget_oracle|3|28.098|1.075|0.9278|74.082|
|167276d9a69a / queue|planned_latency_ms|queue|3|16.755|0.528|0.9694|85.428|
|167276d9a69a / queue|planned_latency_ms|queue+own_budget_oracle|3|28.099|1.074|0.9278|74.084|
|167276d9a69a / queue|wait_ms|queue|3|16.681|0.431|0.9778|85.408|
|167276d9a69a / queue|wait_ms|queue+own_budget_oracle|3|28.018|1.047|0.9389|74.070|
|167276d9a69a / queue_per_capacity|callback_ms|queue_per_capacity|3|5.100|0.111|0.9722|-4.417|
|167276d9a69a / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|1.355|0.064|0.9028|-0.672|
|167276d9a69a / queue_per_capacity|latency_ms|queue_per_capacity|3|16.754|0.528|0.9694|85.425|
|167276d9a69a / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|28.098|1.075|0.9278|74.082|
|167276d9a69a / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|16.755|0.528|0.9694|85.428|
|167276d9a69a / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|28.099|1.074|0.9278|74.084|
|167276d9a69a / queue_per_capacity|wait_ms|queue_per_capacity|3|16.681|0.431|0.9778|85.408|
|167276d9a69a / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|28.018|1.047|0.9389|74.070|
|167276d9a69a / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|5.100|0.111|0.9722|-4.417|
|167276d9a69a / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|1.355|0.064|0.9028|-0.672|
|167276d9a69a / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|16.754|0.528|0.9694|85.425|
|167276d9a69a / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|28.098|1.075|0.9278|74.082|
|167276d9a69a / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|16.755|0.528|0.9694|85.428|
|167276d9a69a / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|28.099|1.074|0.9278|74.084|
|167276d9a69a / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|16.681|0.431|0.9778|85.408|
|167276d9a69a / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|28.018|1.047|0.9389|74.070|
|167276d9a69a / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|5.100|0.111|0.9722|-4.417|
|167276d9a69a / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|1.355|0.064|0.9028|-0.672|
|167276d9a69a / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|16.754|0.528|0.9694|85.425|
|167276d9a69a / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|28.098|1.075|0.9278|74.082|
|167276d9a69a / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|16.755|0.528|0.9694|85.428|
|167276d9a69a / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|28.099|1.074|0.9278|74.084|
|167276d9a69a / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|16.681|0.431|0.9778|85.408|
|167276d9a69a / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|28.018|1.047|0.9389|74.070|
|5908751cb72e / burst_context_remaining|callback_ms|burst_context_remaining|3|53.762|1.200|0.9750|-25.185|
|5908751cb72e / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|21.032|1.233|0.9306|7.545|
|5908751cb72e / burst_context_remaining|latency_ms|burst_context_remaining|3|53.512|1.091|0.9667|-9.758|
|5908751cb72e / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|20.109|1.075|0.9222|23.644|
|5908751cb72e / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|53.639|1.110|0.9667|-9.789|
|5908751cb72e / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|20.183|1.093|0.9222|23.667|
|5908751cb72e / burst_context_remaining|wait_ms|burst_context_remaining|3|9.565|0.310|0.9694|47.215|
|5908751cb72e / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|14.748|0.986|0.9444|42.032|
|5908751cb72e / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|54.802|1.156|0.9722|-26.224|
|5908751cb72e / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|23.890|0.927|0.9361|4.688|
|5908751cb72e / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|53.833|1.159|0.9667|-10.080|
|5908751cb72e / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|21.353|0.815|0.9417|22.400|
|5908751cb72e / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|53.935|1.171|0.9667|-10.084|
|5908751cb72e / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|21.350|0.869|0.9389|22.501|
|5908751cb72e / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|11.381|0.376|0.9750|45.399|
|5908751cb72e / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|20.177|0.889|0.9389|36.603|
|5908751cb72e / queue|callback_ms|queue|3|55.662|1.278|0.9694|-27.084|
|5908751cb72e / queue|callback_ms|queue+own_budget_oracle|3|23.416|0.995|0.9361|5.162|
|5908751cb72e / queue|latency_ms|queue|3|54.185|1.166|0.9694|-10.432|
|5908751cb72e / queue|latency_ms|queue+own_budget_oracle|3|22.050|1.027|0.9306|21.703|
|5908751cb72e / queue|planned_latency_ms|queue|3|54.306|1.196|0.9667|-10.456|
|5908751cb72e / queue|planned_latency_ms|queue+own_budget_oracle|3|22.128|1.064|0.9306|21.723|
|5908751cb72e / queue|wait_ms|queue|3|13.005|0.515|0.9694|43.775|
|5908751cb72e / queue|wait_ms|queue+own_budget_oracle|3|19.837|1.048|0.9333|36.944|
|5908751cb72e / queue_per_capacity|callback_ms|queue_per_capacity|3|55.662|1.278|0.9694|-27.084|
|5908751cb72e / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|23.416|0.995|0.9361|5.162|
|5908751cb72e / queue_per_capacity|latency_ms|queue_per_capacity|3|54.185|1.166|0.9694|-10.432|
|5908751cb72e / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|22.050|1.027|0.9306|21.703|
|5908751cb72e / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|54.306|1.196|0.9667|-10.456|
|5908751cb72e / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|22.128|1.064|0.9306|21.723|
|5908751cb72e / queue_per_capacity|wait_ms|queue_per_capacity|3|13.005|0.515|0.9694|43.775|
|5908751cb72e / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|19.837|1.048|0.9333|36.944|
|5908751cb72e / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|54.802|1.156|0.9722|-26.224|
|5908751cb72e / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|23.890|0.927|0.9361|4.688|
|5908751cb72e / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|53.833|1.159|0.9667|-10.080|
|5908751cb72e / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|21.353|0.815|0.9417|22.400|
|5908751cb72e / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|53.935|1.171|0.9667|-10.084|
|5908751cb72e / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|21.350|0.869|0.9389|22.501|
|5908751cb72e / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|11.381|0.376|0.9750|45.399|
|5908751cb72e / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|20.177|0.889|0.9389|36.603|
|5908751cb72e / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|54.802|1.156|0.9722|-26.224|
|5908751cb72e / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|23.890|0.927|0.9361|4.688|
|5908751cb72e / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|53.833|1.159|0.9667|-10.080|
|5908751cb72e / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|21.353|0.815|0.9417|22.400|
|5908751cb72e / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|53.935|1.171|0.9667|-10.084|
|5908751cb72e / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|21.350|0.869|0.9389|22.501|
|5908751cb72e / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|11.381|0.376|0.9750|45.399|
|5908751cb72e / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|20.177|0.889|0.9389|36.603|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|

检测到work与outstanding仅为同一信号的常数缩放：167276d9a69a, 5908751cb72e。这不构成两个独立指标发现。

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
