# 阶段3：指标质量与阈值均衡

读取 18 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|negative-t16-spread-home / 11000 / observe|True|400/400|14.451|28.970|6.465|7.168|0.000|
|main-t1-local-home / 11000 / observe|True|400/400|20.987|43.266|18.906|1.995|0.000|
|negative-t16-smooth-home / 11000 / observe|True|400/400|2.110|3.270|0.049|2.000|0.000|
|main-t16-local-home / 11000 / observe|True|400/400|25.660|43.964|14.247|10.900|0.000|
|negative-t1-spread-home / 11000 / observe|True|400/400|11.220|23.418|9.107|2.023|0.000|
|negative-t1-smooth-home / 11000 / observe|True|400/400|2.106|3.425|0.020|2.025|0.000|
|negative-t1-spread-home / 11001 / observe|True|400/400|10.894|22.406|8.827|1.985|0.000|
|negative-t16-spread-home / 11001 / observe|True|400/400|15.213|41.780|7.094|7.423|0.000|
|main-t1-local-home / 11001 / observe|True|400/400|20.690|42.301|18.623|1.984|0.000|
|main-t16-local-home / 11001 / observe|True|400/400|25.555|45.044|14.143|10.905|0.000|
|negative-t1-smooth-home / 11001 / observe|True|400/400|2.069|3.015|0.023|1.985|0.000|
|negative-t16-smooth-home / 11001 / observe|True|400/400|2.134|3.696|0.040|2.011|0.000|
|main-t16-local-home / 11002 / observe|True|400/400|26.289|44.913|14.864|10.983|0.000|
|negative-t16-spread-home / 11002 / observe|True|400/400|14.634|29.599|6.805|7.281|0.000|
|negative-t16-smooth-home / 11002 / observe|True|400/400|2.371|9.599|0.140|2.167|0.000|
|negative-t1-smooth-home / 11002 / observe|True|400/400|2.068|3.075|0.010|2.000|0.000|
|main-t1-local-home / 11002 / observe|True|400/400|21.303|42.632|19.218|2.000|0.000|
|negative-t1-spread-home / 11002 / observe|True|400/400|11.163|22.762|9.077|2.000|0.000|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
没有可比较的routing候选；观测阶段不产生均衡收益结论。

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|
|04b004a12945 / burst_context_remaining|callback_ms|burst_context_remaining|3|0.516|0.016|0.9783|-0.442|
|04b004a12945 / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|0.134|0.011|0.9617|-0.060|
|04b004a12945 / burst_context_remaining|latency_ms|burst_context_remaining|3|1.324|0.045|0.9850|3.719|
|04b004a12945 / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|1.649|0.054|0.9817|3.394|
|04b004a12945 / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|1.325|0.045|0.9858|3.722|
|04b004a12945 / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|1.651|0.055|0.9817|3.396|
|04b004a12945 / burst_context_remaining|wait_ms|burst_context_remaining|3|1.241|0.038|0.9875|3.803|
|04b004a12945 / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|1.647|0.054|0.9842|3.396|
|04b004a12945 / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|0.521|0.016|0.9775|-0.447|
|04b004a12945 / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|0.134|0.011|0.9642|-0.060|
|04b004a12945 / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|1.240|0.040|0.9900|3.802|
|04b004a12945 / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|1.562|0.052|0.9808|3.481|
|04b004a12945 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|1.241|0.040|0.9900|3.806|
|04b004a12945 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|1.565|0.053|0.9808|3.482|
|04b004a12945 / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|1.078|0.038|0.9875|3.965|
|04b004a12945 / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|1.553|0.052|0.9792|3.490|
|04b004a12945 / queue|callback_ms|queue|3|0.521|0.016|0.9775|-0.447|
|04b004a12945 / queue|callback_ms|queue+own_budget_oracle|3|0.134|0.011|0.9642|-0.060|
|04b004a12945 / queue|latency_ms|queue|3|1.243|0.044|0.9900|3.799|
|04b004a12945 / queue|latency_ms|queue+own_budget_oracle|3|1.573|0.051|0.9817|3.470|
|04b004a12945 / queue|planned_latency_ms|queue|3|1.244|0.044|0.9900|3.802|
|04b004a12945 / queue|planned_latency_ms|queue+own_budget_oracle|3|1.576|0.051|0.9817|3.471|
|04b004a12945 / queue|wait_ms|queue|3|1.087|0.041|0.9858|3.956|
|04b004a12945 / queue|wait_ms|queue+own_budget_oracle|3|1.563|0.051|0.9792|3.480|
|04b004a12945 / queue_per_capacity|callback_ms|queue_per_capacity|3|0.521|0.016|0.9775|-0.447|
|04b004a12945 / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|0.134|0.011|0.9642|-0.060|
|04b004a12945 / queue_per_capacity|latency_ms|queue_per_capacity|3|1.243|0.044|0.9900|3.799|
|04b004a12945 / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|1.573|0.051|0.9817|3.470|
|04b004a12945 / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|1.244|0.044|0.9900|3.802|
|04b004a12945 / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|1.576|0.051|0.9817|3.471|
|04b004a12945 / queue_per_capacity|wait_ms|queue_per_capacity|3|1.087|0.041|0.9858|3.956|
|04b004a12945 / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|1.563|0.051|0.9792|3.480|
|04b004a12945 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|0.521|0.016|0.9775|-0.447|
|04b004a12945 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.134|0.011|0.9642|-0.060|
|04b004a12945 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|1.240|0.040|0.9900|3.802|
|04b004a12945 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|1.562|0.052|0.9808|3.481|
|04b004a12945 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|1.241|0.040|0.9900|3.806|
|04b004a12945 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|1.565|0.053|0.9808|3.482|
|04b004a12945 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|1.078|0.038|0.9875|3.965|
|04b004a12945 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|1.553|0.052|0.9792|3.490|
|04b004a12945 / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|0.521|0.016|0.9775|-0.447|
|04b004a12945 / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|0.134|0.011|0.9642|-0.060|
|04b004a12945 / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|1.240|0.040|0.9900|3.802|
|04b004a12945 / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|1.562|0.052|0.9808|3.481|
|04b004a12945 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|1.241|0.040|0.9900|3.806|
|04b004a12945 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|1.565|0.053|0.9808|3.482|
|04b004a12945 / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|1.078|0.038|0.9875|3.965|
|04b004a12945 / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|1.553|0.052|0.9792|3.490|
|1d6a4f2a482f / burst_context_remaining|callback_ms|burst_context_remaining|3|5.664|0.168|0.9833|-0.824|
|1d6a4f2a482f / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|4.468|0.124|0.9842|0.373|
|1d6a4f2a482f / burst_context_remaining|latency_ms|burst_context_remaining|3|6.192|0.185|0.9833|3.191|
|1d6a4f2a482f / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|5.409|0.197|0.9775|3.974|
|1d6a4f2a482f / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|6.146|0.182|0.9850|3.240|
|1d6a4f2a482f / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|5.354|0.197|0.9783|4.032|
|1d6a4f2a482f / burst_context_remaining|wait_ms|burst_context_remaining|3|2.106|0.146|0.9817|6.046|
|1d6a4f2a482f / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|2.751|0.136|0.9775|5.400|
|1d6a4f2a482f / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|5.634|0.178|0.9808|-0.794|
|1d6a4f2a482f / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|4.473|0.140|0.9792|0.367|
|1d6a4f2a482f / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|6.152|0.182|0.9842|3.231|
|1d6a4f2a482f / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|5.279|0.175|0.9833|4.104|
|1d6a4f2a482f / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|6.099|0.176|0.9858|3.287|
|1d6a4f2a482f / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|5.222|0.172|0.9850|4.163|
|1d6a4f2a482f / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|2.074|0.146|0.9825|6.077|
|1d6a4f2a482f / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|2.687|0.148|0.9783|5.464|
|1d6a4f2a482f / queue|callback_ms|queue|3|5.659|0.180|0.9808|-0.818|
|1d6a4f2a482f / queue|callback_ms|queue+own_budget_oracle|3|4.494|0.138|0.9800|0.347|
|1d6a4f2a482f / queue|latency_ms|queue|3|6.139|0.183|0.9833|3.244|
|1d6a4f2a482f / queue|latency_ms|queue+own_budget_oracle|3|5.320|0.177|0.9825|4.063|
|1d6a4f2a482f / queue|planned_latency_ms|queue|3|6.139|0.179|0.9850|3.247|
|1d6a4f2a482f / queue|planned_latency_ms|queue+own_budget_oracle|3|5.285|0.179|0.9833|4.101|
|1d6a4f2a482f / queue|wait_ms|queue|3|2.021|0.138|0.9817|6.130|
|1d6a4f2a482f / queue|wait_ms|queue+own_budget_oracle|3|2.649|0.141|0.9800|5.502|
|1d6a4f2a482f / queue_per_capacity|callback_ms|queue_per_capacity|3|5.659|0.180|0.9808|-0.818|
|1d6a4f2a482f / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|4.494|0.138|0.9800|0.347|
|1d6a4f2a482f / queue_per_capacity|latency_ms|queue_per_capacity|3|6.139|0.183|0.9833|3.244|
|1d6a4f2a482f / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|5.320|0.177|0.9825|4.063|
|1d6a4f2a482f / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|6.139|0.179|0.9850|3.247|
|1d6a4f2a482f / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|5.285|0.179|0.9833|4.101|
|1d6a4f2a482f / queue_per_capacity|wait_ms|queue_per_capacity|3|2.021|0.138|0.9817|6.130|
|1d6a4f2a482f / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|2.649|0.141|0.9800|5.502|
|1d6a4f2a482f / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|5.634|0.178|0.9808|-0.794|
|1d6a4f2a482f / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|4.473|0.140|0.9792|0.367|
|1d6a4f2a482f / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|6.152|0.182|0.9842|3.231|
|1d6a4f2a482f / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|5.279|0.175|0.9833|4.104|
|1d6a4f2a482f / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|6.099|0.176|0.9858|3.287|
|1d6a4f2a482f / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|5.222|0.172|0.9850|4.163|
|1d6a4f2a482f / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|2.074|0.146|0.9825|6.077|
|1d6a4f2a482f / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.687|0.148|0.9783|5.464|
|1d6a4f2a482f / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|5.634|0.178|0.9808|-0.794|
|1d6a4f2a482f / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|4.473|0.140|0.9792|0.367|
|1d6a4f2a482f / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|6.152|0.182|0.9842|3.231|
|1d6a4f2a482f / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|5.279|0.175|0.9833|4.104|
|1d6a4f2a482f / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|6.099|0.176|0.9858|3.287|
|1d6a4f2a482f / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|5.222|0.172|0.9850|4.163|
|1d6a4f2a482f / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|2.074|0.146|0.9825|6.077|
|1d6a4f2a482f / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|2.687|0.148|0.9783|5.464|
|1d9a8d55e804 / burst_context_remaining|callback_ms|burst_context_remaining|3|0.510|0.011|0.9817|-0.445|
|1d9a8d55e804 / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|0.126|0.003|0.9767|-0.060|
|1d9a8d55e804 / burst_context_remaining|latency_ms|burst_context_remaining|3|2.049|0.064|0.9892|7.954|
|1d9a8d55e804 / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|2.980|0.092|0.9808|7.023|
|1d9a8d55e804 / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|2.051|0.064|0.9892|7.956|
|1d9a8d55e804 / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|2.982|0.092|0.9808|7.025|
|1d9a8d55e804 / burst_context_remaining|wait_ms|burst_context_remaining|3|1.987|0.061|0.9875|8.016|
|1d9a8d55e804 / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|2.981|0.092|0.9783|7.022|
|1d9a8d55e804 / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|0.513|0.011|0.9817|-0.448|
|1d9a8d55e804 / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|0.126|0.003|0.9733|-0.061|
|1d9a8d55e804 / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|2.009|0.064|0.9842|7.994|
|1d9a8d55e804 / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|2.940|0.093|0.9825|7.063|
|1d9a8d55e804 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|2.010|0.064|0.9842|7.996|
|1d9a8d55e804 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|2.942|0.093|0.9825|7.065|
|1d9a8d55e804 / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|1.938|0.061|0.9875|8.065|
|1d9a8d55e804 / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|2.935|0.094|0.9808|7.068|
|1d9a8d55e804 / queue|callback_ms|queue|3|0.513|0.011|0.9817|-0.448|
|1d9a8d55e804 / queue|callback_ms|queue+own_budget_oracle|3|0.126|0.003|0.9750|-0.061|
|1d9a8d55e804 / queue|latency_ms|queue|3|2.051|0.072|0.9825|7.952|
|1d9a8d55e804 / queue|latency_ms|queue+own_budget_oracle|3|2.960|0.093|0.9825|7.043|
|1d9a8d55e804 / queue|planned_latency_ms|queue|3|2.053|0.072|0.9825|7.954|
|1d9a8d55e804 / queue|planned_latency_ms|queue+own_budget_oracle|3|2.962|0.093|0.9825|7.045|
|1d9a8d55e804 / queue|wait_ms|queue|3|1.982|0.070|0.9867|8.021|
|1d9a8d55e804 / queue|wait_ms|queue+own_budget_oracle|3|2.953|0.093|0.9808|7.050|
|1d9a8d55e804 / queue_per_capacity|callback_ms|queue_per_capacity|3|0.513|0.011|0.9817|-0.448|
|1d9a8d55e804 / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|0.126|0.003|0.9750|-0.061|
|1d9a8d55e804 / queue_per_capacity|latency_ms|queue_per_capacity|3|2.051|0.072|0.9825|7.952|
|1d9a8d55e804 / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|2.960|0.093|0.9825|7.043|
|1d9a8d55e804 / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|2.053|0.072|0.9825|7.954|
|1d9a8d55e804 / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|2.962|0.093|0.9825|7.045|
|1d9a8d55e804 / queue_per_capacity|wait_ms|queue_per_capacity|3|1.982|0.070|0.9867|8.021|
|1d9a8d55e804 / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|2.953|0.093|0.9808|7.050|
|1d9a8d55e804 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|0.513|0.011|0.9817|-0.448|
|1d9a8d55e804 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.126|0.003|0.9733|-0.061|
|1d9a8d55e804 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|2.009|0.064|0.9842|7.994|
|1d9a8d55e804 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.940|0.093|0.9825|7.063|
|1d9a8d55e804 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|2.010|0.064|0.9842|7.996|
|1d9a8d55e804 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.942|0.093|0.9825|7.065|
|1d9a8d55e804 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|1.938|0.061|0.9875|8.065|
|1d9a8d55e804 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.935|0.094|0.9808|7.068|
|1d9a8d55e804 / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|0.513|0.011|0.9817|-0.448|
|1d9a8d55e804 / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|0.126|0.003|0.9733|-0.061|
|1d9a8d55e804 / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|2.009|0.064|0.9842|7.994|
|1d9a8d55e804 / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|2.940|0.093|0.9825|7.063|
|1d9a8d55e804 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|2.010|0.064|0.9842|7.996|
|1d9a8d55e804 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|2.942|0.093|0.9825|7.065|
|1d9a8d55e804 / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|1.938|0.061|0.9875|8.065|
|1d9a8d55e804 / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|2.935|0.094|0.9808|7.068|
|2197878ffffa / burst_context_remaining|callback_ms|burst_context_remaining|3|4.109|0.160|0.9833|-0.961|
|2197878ffffa / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|2.849|0.163|0.9775|0.299|
|2197878ffffa / burst_context_remaining|latency_ms|burst_context_remaining|3|4.720|0.380|0.9775|-0.053|
|2197878ffffa / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|3.746|0.392|0.9758|0.921|
|2197878ffffa / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|4.688|0.384|0.9775|-0.015|
|2197878ffffa / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|3.737|0.400|0.9758|0.936|
|2197878ffffa / burst_context_remaining|wait_ms|burst_context_remaining|3|1.976|0.287|0.9758|2.265|
|2197878ffffa / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|2.160|0.315|0.9767|2.081|
|2197878ffffa / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|4.076|0.152|0.9883|-0.927|
|2197878ffffa / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|2.879|0.160|0.9792|0.270|
|2197878ffffa / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|4.591|0.368|0.9808|0.076|
|2197878ffffa / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|3.653|0.382|0.9742|1.014|
|2197878ffffa / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|4.582|0.372|0.9800|0.092|
|2197878ffffa / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|3.647|0.391|0.9725|1.026|
|2197878ffffa / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|1.830|0.260|0.9783|2.411|
|2197878ffffa / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|2.053|0.314|0.9733|2.188|
|2197878ffffa / queue|callback_ms|queue|3|4.149|0.142|0.9883|-1.000|
|2197878ffffa / queue|callback_ms|queue+own_budget_oracle|3|2.930|0.170|0.9750|0.219|
|2197878ffffa / queue|latency_ms|queue|3|4.719|0.369|0.9808|-0.052|
|2197878ffffa / queue|latency_ms|queue+own_budget_oracle|3|3.688|0.401|0.9692|0.979|
|2197878ffffa / queue|planned_latency_ms|queue|3|4.734|0.370|0.9800|-0.060|
|2197878ffffa / queue|planned_latency_ms|queue+own_budget_oracle|3|3.715|0.415|0.9667|0.959|
|2197878ffffa / queue|wait_ms|queue|3|1.877|0.301|0.9800|2.364|
|2197878ffffa / queue|wait_ms|queue+own_budget_oracle|3|2.053|0.351|0.9708|2.188|
|2197878ffffa / queue_per_capacity|callback_ms|queue_per_capacity|3|4.149|0.142|0.9883|-1.000|
|2197878ffffa / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|2.930|0.170|0.9750|0.219|
|2197878ffffa / queue_per_capacity|latency_ms|queue_per_capacity|3|4.719|0.369|0.9808|-0.052|
|2197878ffffa / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|3.688|0.401|0.9692|0.979|
|2197878ffffa / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|4.734|0.370|0.9800|-0.060|
|2197878ffffa / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|3.715|0.415|0.9667|0.959|
|2197878ffffa / queue_per_capacity|wait_ms|queue_per_capacity|3|1.877|0.301|0.9800|2.364|
|2197878ffffa / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|2.053|0.351|0.9708|2.188|
|2197878ffffa / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|4.076|0.152|0.9883|-0.927|
|2197878ffffa / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.879|0.160|0.9792|0.270|
|2197878ffffa / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|4.591|0.368|0.9808|0.076|
|2197878ffffa / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|3.653|0.382|0.9742|1.014|
|2197878ffffa / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|4.582|0.372|0.9800|0.092|
|2197878ffffa / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|3.647|0.391|0.9725|1.026|
|2197878ffffa / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|1.830|0.260|0.9783|2.411|
|2197878ffffa / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|2.053|0.314|0.9733|2.188|
|2197878ffffa / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|4.076|0.152|0.9883|-0.927|
|2197878ffffa / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|2.879|0.160|0.9792|0.270|
|2197878ffffa / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|4.591|0.368|0.9808|0.076|
|2197878ffffa / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|3.653|0.382|0.9742|1.014|
|2197878ffffa / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|4.582|0.372|0.9800|0.092|
|2197878ffffa / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|3.647|0.391|0.9725|1.026|
|2197878ffffa / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|1.830|0.260|0.9783|2.411|
|2197878ffffa / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|2.053|0.314|0.9733|2.188|
|4877d558c3ff / burst_context_remaining|callback_ms|burst_context_remaining|3|0.580|0.071|0.9858|-0.405|
|4877d558c3ff / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|0.213|0.081|0.9833|-0.037|
|4877d558c3ff / burst_context_remaining|latency_ms|burst_context_remaining|3|0.633|0.114|0.9858|-0.359|
|4877d558c3ff / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|0.297|0.124|0.9842|-0.023|
|4877d558c3ff / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|0.640|0.113|0.9842|-0.352|
|4877d558c3ff / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|0.309|0.126|0.9833|-0.021|
|4877d558c3ff / burst_context_remaining|wait_ms|burst_context_remaining|3|0.125|0.051|0.9858|0.000|
|4877d558c3ff / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|0.125|0.054|0.9858|0.000|
|4877d558c3ff / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|0.580|0.071|0.9858|-0.405|
|4877d558c3ff / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|0.213|0.081|0.9833|-0.037|
|4877d558c3ff / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|0.633|0.114|0.9858|-0.359|
|4877d558c3ff / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|0.297|0.124|0.9842|-0.023|
|4877d558c3ff / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|0.640|0.113|0.9842|-0.352|
|4877d558c3ff / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|0.309|0.126|0.9833|-0.021|
|4877d558c3ff / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|0.125|0.051|0.9858|0.000|
|4877d558c3ff / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|0.125|0.054|0.9858|0.000|
|4877d558c3ff / queue|callback_ms|queue|3|0.580|0.071|0.9858|-0.405|
|4877d558c3ff / queue|callback_ms|queue+own_budget_oracle|3|0.213|0.081|0.9833|-0.037|
|4877d558c3ff / queue|latency_ms|queue|3|0.633|0.114|0.9858|-0.359|
|4877d558c3ff / queue|latency_ms|queue+own_budget_oracle|3|0.297|0.124|0.9842|-0.023|
|4877d558c3ff / queue|planned_latency_ms|queue|3|0.640|0.113|0.9842|-0.352|
|4877d558c3ff / queue|planned_latency_ms|queue+own_budget_oracle|3|0.309|0.126|0.9833|-0.021|
|4877d558c3ff / queue|wait_ms|queue|3|0.125|0.051|0.9858|0.000|
|4877d558c3ff / queue|wait_ms|queue+own_budget_oracle|3|0.125|0.054|0.9858|0.000|
|4877d558c3ff / queue_per_capacity|callback_ms|queue_per_capacity|3|0.580|0.071|0.9858|-0.405|
|4877d558c3ff / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|0.213|0.081|0.9833|-0.037|
|4877d558c3ff / queue_per_capacity|latency_ms|queue_per_capacity|3|0.633|0.114|0.9858|-0.359|
|4877d558c3ff / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|0.297|0.124|0.9842|-0.023|
|4877d558c3ff / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|0.640|0.113|0.9842|-0.352|
|4877d558c3ff / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|0.309|0.126|0.9833|-0.021|
|4877d558c3ff / queue_per_capacity|wait_ms|queue_per_capacity|3|0.125|0.051|0.9858|0.000|
|4877d558c3ff / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|0.125|0.054|0.9858|0.000|
|4877d558c3ff / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|0.580|0.071|0.9858|-0.405|
|4877d558c3ff / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.213|0.081|0.9833|-0.037|
|4877d558c3ff / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|0.633|0.114|0.9858|-0.359|
|4877d558c3ff / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.297|0.124|0.9842|-0.023|
|4877d558c3ff / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|0.640|0.113|0.9842|-0.352|
|4877d558c3ff / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.309|0.126|0.9833|-0.021|
|4877d558c3ff / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|0.125|0.051|0.9858|0.000|
|4877d558c3ff / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.125|0.054|0.9858|0.000|
|4877d558c3ff / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|0.580|0.071|0.9858|-0.405|
|4877d558c3ff / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|0.213|0.081|0.9833|-0.037|
|4877d558c3ff / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|0.633|0.114|0.9858|-0.359|
|4877d558c3ff / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|0.297|0.124|0.9842|-0.023|
|4877d558c3ff / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|0.640|0.113|0.9842|-0.352|
|4877d558c3ff / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|0.309|0.126|0.9833|-0.021|
|4877d558c3ff / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|0.125|0.051|0.9858|0.000|
|4877d558c3ff / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|0.125|0.054|0.9858|0.000|
|963eee024fe5 / burst_context_remaining|callback_ms|burst_context_remaining|3|0.515|0.013|0.9825|-0.440|
|963eee024fe5 / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|0.134|0.013|0.9767|-0.059|
|963eee024fe5 / burst_context_remaining|latency_ms|burst_context_remaining|3|0.520|0.017|0.9808|-0.437|
|963eee024fe5 / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|0.141|0.019|0.9783|-0.058|
|963eee024fe5 / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|0.521|0.017|0.9808|-0.436|
|963eee024fe5 / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|0.143|0.019|0.9750|-0.058|
|963eee024fe5 / burst_context_remaining|wait_ms|burst_context_remaining|3|0.015|0.007|0.9867|0.001|
|963eee024fe5 / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|0.016|0.008|0.9867|0.000|
|963eee024fe5 / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|0.515|0.013|0.9825|-0.440|
|963eee024fe5 / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|0.134|0.013|0.9767|-0.059|
|963eee024fe5 / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|0.520|0.017|0.9808|-0.437|
|963eee024fe5 / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|0.141|0.019|0.9783|-0.058|
|963eee024fe5 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|0.521|0.017|0.9808|-0.436|
|963eee024fe5 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|0.143|0.019|0.9750|-0.058|
|963eee024fe5 / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|0.015|0.007|0.9867|0.001|
|963eee024fe5 / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|0.016|0.008|0.9867|0.000|
|963eee024fe5 / queue|callback_ms|queue|3|0.515|0.013|0.9825|-0.440|
|963eee024fe5 / queue|callback_ms|queue+own_budget_oracle|3|0.134|0.013|0.9767|-0.059|
|963eee024fe5 / queue|latency_ms|queue|3|0.520|0.017|0.9808|-0.437|
|963eee024fe5 / queue|latency_ms|queue+own_budget_oracle|3|0.141|0.019|0.9783|-0.058|
|963eee024fe5 / queue|planned_latency_ms|queue|3|0.521|0.017|0.9808|-0.436|
|963eee024fe5 / queue|planned_latency_ms|queue+own_budget_oracle|3|0.143|0.019|0.9750|-0.058|
|963eee024fe5 / queue|wait_ms|queue|3|0.015|0.007|0.9867|0.001|
|963eee024fe5 / queue|wait_ms|queue+own_budget_oracle|3|0.016|0.008|0.9867|0.000|
|963eee024fe5 / queue_per_capacity|callback_ms|queue_per_capacity|3|0.515|0.013|0.9825|-0.440|
|963eee024fe5 / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|0.134|0.013|0.9767|-0.059|
|963eee024fe5 / queue_per_capacity|latency_ms|queue_per_capacity|3|0.520|0.017|0.9808|-0.437|
|963eee024fe5 / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|0.141|0.019|0.9783|-0.058|
|963eee024fe5 / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|0.521|0.017|0.9808|-0.436|
|963eee024fe5 / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|0.143|0.019|0.9750|-0.058|
|963eee024fe5 / queue_per_capacity|wait_ms|queue_per_capacity|3|0.015|0.007|0.9867|0.001|
|963eee024fe5 / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|0.016|0.008|0.9867|0.000|
|963eee024fe5 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|0.515|0.013|0.9825|-0.440|
|963eee024fe5 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.134|0.013|0.9767|-0.059|
|963eee024fe5 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|0.520|0.017|0.9808|-0.437|
|963eee024fe5 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.141|0.019|0.9783|-0.058|
|963eee024fe5 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|0.521|0.017|0.9808|-0.436|
|963eee024fe5 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.143|0.019|0.9750|-0.058|
|963eee024fe5 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|0.015|0.007|0.9867|0.001|
|963eee024fe5 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.016|0.008|0.9867|0.000|
|963eee024fe5 / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|0.515|0.013|0.9825|-0.440|
|963eee024fe5 / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|0.134|0.013|0.9767|-0.059|
|963eee024fe5 / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|0.520|0.017|0.9808|-0.437|
|963eee024fe5 / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|0.141|0.019|0.9783|-0.058|
|963eee024fe5 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|0.521|0.017|0.9808|-0.436|
|963eee024fe5 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|0.143|0.019|0.9750|-0.058|
|963eee024fe5 / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|0.015|0.007|0.9867|0.001|
|963eee024fe5 / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|0.016|0.008|0.9867|0.000|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|

检测到work与outstanding仅为同一信号的常数缩放：1d9a8d55e804, 1d6a4f2a482f, 04b004a12945, 4877d558c3ff, 2197878ffffa。这不构成两个独立指标发现。

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
