# 阶段3：指标质量与阈值均衡

读取 48 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|main-t16-local-queue-h2 / 21000 / tune|True|400/400|14.381|23.904|6.421|7.274|0.468|
|main-t1-local-remaining-h4 / 21000 / tune|True|400/400|11.174|22.427|9.085|2.002|0.500|
|main-t1-local-spread-policy / 21000 / tune|True|400/400|11.180|21.928|9.091|2.003|0.500|
|main-t16-local-spread-policy / 21000 / tune|True|400/400|13.722|22.782|6.046|7.037|0.500|
|main-t1-local-outstanding-h0.5 / 21000 / tune|True|400/400|11.530|26.949|9.408|2.040|0.500|
|main-t16-local-remaining-h1 / 21000 / tune|True|400/400|14.335|35.192|6.569|7.222|0.492|
|main-t1-local-home / 21000 / tune|True|400/400|21.263|42.987|19.180|2.002|0.000|
|main-t16-local-outstanding-h2 / 21000 / tune|True|400/400|13.801|22.820|6.113|7.236|0.500|
|main-t1-local-queue-h2 / 21000 / tune|True|400/400|11.476|24.809|9.360|2.030|0.485|
|main-t1-local-queue-h0.5 / 21000 / tune|True|400/400|12.012|32.565|9.835|2.082|0.482|
|main-t16-local-queue-h0.5 / 21000 / tune|True|400/400|14.055|23.819|6.339|7.184|0.472|
|main-t16-local-home / 21000 / tune|True|400/400|25.904|44.510|14.096|11.109|0.000|
|main-t16-local-remaining-h4 / 21000 / tune|True|400/400|14.443|32.588|6.626|7.329|0.497|
|main-t16-local-outstanding-h0.5 / 21000 / tune|True|400/400|13.878|22.953|5.937|7.026|0.485|
|main-t1-local-outstanding-h2 / 21000 / tune|True|400/400|11.173|22.434|9.085|2.003|0.500|
|main-t1-local-remaining-h1 / 21000 / tune|True|400/400|11.692|26.132|9.554|2.053|0.500|
|main-t16-local-home / 21001 / tune|True|400/400|26.042|41.742|14.650|10.733|0.000|
|main-t1-local-remaining-h4 / 21001 / tune|True|400/400|11.156|21.672|9.077|1.995|0.500|
|main-t1-local-spread-policy / 21001 / tune|True|400/400|11.140|22.189|9.064|1.995|0.500|
|main-t16-local-remaining-h1 / 21001 / tune|True|400/400|13.917|22.263|6.087|6.961|0.492|
|main-t16-local-queue-h0.5 / 21001 / tune|True|400/400|15.731|36.895|7.295|7.475|0.477|
|main-t1-local-remaining-h1 / 21001 / tune|True|400/400|11.435|23.607|9.323|2.027|0.500|
|main-t1-local-outstanding-h2 / 21001 / tune|True|400/400|11.182|21.672|9.098|1.997|0.500|
|main-t16-local-outstanding-h2 / 21001 / tune|True|400/400|14.561|32.321|6.705|7.238|0.490|
|main-t16-local-queue-h2 / 21001 / tune|True|400/400|13.889|23.126|6.014|7.148|0.475|
|main-t16-local-remaining-h4 / 21001 / tune|True|400/400|13.878|22.891|6.147|7.053|0.492|
|main-t16-local-spread-policy / 21001 / tune|True|400/400|13.829|22.259|6.100|7.136|0.500|
|main-t1-local-queue-h0.5 / 21001 / tune|True|400/400|11.241|22.966|9.159|1.995|0.485|
|main-t16-local-outstanding-h0.5 / 21001 / tune|True|400/400|14.130|23.142|5.953|7.146|0.487|
|main-t1-local-queue-h2 / 21001 / tune|True|400/400|11.197|22.310|9.117|1.996|0.487|
|main-t1-local-home / 21001 / tune|True|400/400|21.194|41.312|19.118|1.995|0.000|
|main-t1-local-outstanding-h0.5 / 21001 / tune|True|400/400|11.143|22.164|9.063|1.995|0.500|
|main-t16-local-remaining-h1 / 21002 / tune|True|400/400|14.607|39.990|6.550|7.285|0.492|
|main-t16-local-home / 21002 / tune|True|400/400|26.208|52.271|14.280|11.377|0.000|
|main-t16-local-outstanding-h0.5 / 21002 / tune|True|400/400|14.606|38.829|6.428|7.266|0.490|
|main-t16-local-queue-h2 / 21002 / tune|True|400/400|13.826|23.406|5.928|7.235|0.477|
|main-t1-local-home / 21002 / tune|True|400/400|21.105|42.541|18.975|2.015|0.000|
|main-t1-local-queue-h0.5 / 21002 / tune|True|400/400|11.235|23.945|9.125|2.024|0.480|
|main-t16-local-queue-h0.5 / 21002 / tune|True|400/400|14.149|23.285|6.064|7.361|0.475|
|main-t16-local-outstanding-h2 / 21002 / tune|True|400/400|14.051|22.899|5.794|7.278|0.485|
|main-t1-local-remaining-h4 / 21002 / tune|True|400/400|11.105|22.063|9.004|2.016|0.500|
|main-t1-local-remaining-h1 / 21002 / tune|True|400/400|11.092|22.247|8.989|2.017|0.500|
|main-t16-local-remaining-h4 / 21002 / tune|True|400/400|13.829|22.768|5.760|7.326|0.490|
|main-t16-local-spread-policy / 21002 / tune|True|400/400|14.452|37.628|6.446|7.196|0.500|
|main-t1-local-queue-h2 / 21002 / tune|True|400/400|11.117|22.781|9.012|2.016|0.485|
|main-t1-local-outstanding-h2 / 21002 / tune|True|400/400|11.092|22.058|8.987|2.016|0.500|
|main-t1-local-spread-policy / 21002 / tune|True|400/400|13.148|41.553|10.848|2.213|0.500|
|main-t1-local-outstanding-h0.5 / 21002 / tune|True|400/400|11.088|22.078|8.986|2.016|0.500|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
|main-t1-local-outstanding-h0.5 / tune|3/0|-9.933|-18.549|NA|descriptive_only|
|main-t1-local-outstanding-h2 / tune|3/0|-10.038|-20.225|NA|descriptive_only|
|main-t1-local-queue-h0.5 / tune|3/0|-9.691|-15.788|NA|descriptive_only|
|main-t1-local-queue-h2 / tune|3/0|-9.924|-18.980|NA|descriptive_only|
|main-t1-local-remaining-h1 / tune|3/0|-9.780|-18.285|NA|descriptive_only|
|main-t1-local-remaining-h4 / tune|3/0|-10.042|-20.226|NA|descriptive_only|
|main-t1-local-spread-policy / tune|3/0|-9.364|-13.723|NA|descriptive_only|
|main-t16-local-outstanding-h0.5 / tune|3/0|-11.846|-17.867|NA|descriptive_only|
|main-t16-local-outstanding-h2 / tune|3/0|-11.913|-20.161|NA|descriptive_only|
|main-t16-local-queue-h0.5 / tune|3/0|-11.406|-18.175|NA|descriptive_only|
|main-t16-local-queue-h2 / tune|3/0|-12.019|-22.696|NA|descriptive_only|
|main-t16-local-remaining-h1 / tune|3/0|-11.764|-13.693|NA|descriptive_only|
|main-t16-local-remaining-h4 / tune|3/0|-12.001|-20.092|NA|descriptive_only|
|main-t16-local-spread-policy / tune|3/0|-12.050|-18.619|NA|descriptive_only|

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
