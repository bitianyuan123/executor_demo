# 阶段3：指标质量与阈值均衡

读取 42 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|main-t16-local-cost-minimal-outstanding / 41000 / cost|True|240/240|1.583|3.118|0.763|0.273|0.487|
|main-t16-local-cost-minimal-outstanding-home / 41000 / cost|True|240/240|2.742|5.408|2.247|0.371|0.000|
|main-t16-local-cost-basic-home / 41000 / cost|True|240/240|2.740|5.454|2.201|0.372|0.000|
|main-t16-local-cost-basic-outstanding / 41000 / cost|True|240/240|1.578|3.026|0.734|0.283|0.483|
|main-t16-local-cost-progress-queue / 41000 / cost|True|240/240|2.189|4.467|1.608|0.494|0.475|
|main-t16-local-cost-progress-remaining / 41000 / cost|True|240/240|2.183|4.139|1.600|0.497|0.500|
|main-t16-local-cost-off-home / 41000 / cost|True|240/240|2.746|5.409|2.270|0.379|0.000|
|main-t16-local-cost-minimal-remaining-home / 41000 / cost|True|240/240|3.786|7.360|3.013|0.678|0.000|
|main-t16-local-cost-minimal-remaining / 41000 / cost|True|240/240|2.194|4.214|1.606|0.503|0.500|
|main-t16-local-cost-progress-home / 41000 / cost|True|240/240|3.860|7.480|3.047|0.688|0.000|
|main-t16-local-cost-progress-outstanding / 41000 / cost|True|240/240|2.197|4.177|1.608|0.501|0.500|
|main-t16-local-cost-minimal-queue / 41000 / cost|True|240/240|1.620|3.260|0.918|0.282|0.458|
|main-t16-local-cost-basic-queue / 41000 / cost|True|240/240|1.542|3.147|0.774|0.296|0.467|
|main-t16-local-cost-minimal-queue-home / 41000 / cost|True|240/240|2.739|5.435|2.259|0.374|0.000|
|main-t16-local-cost-minimal-outstanding-home / 41001 / cost|True|240/240|2.756|5.551|2.263|0.393|0.000|
|main-t16-local-cost-minimal-remaining-home / 41001 / cost|True|240/240|4.128|8.586|3.212|0.756|0.000|
|main-t16-local-cost-minimal-queue / 41001 / cost|True|240/240|1.579|3.245|0.879|0.298|0.467|
|main-t16-local-cost-progress-remaining / 41001 / cost|True|240/240|2.218|4.459|1.618|0.515|0.500|
|main-t16-local-cost-progress-outstanding / 41001 / cost|True|240/240|2.218|4.456|1.619|0.514|0.500|
|main-t16-local-cost-basic-queue / 41001 / cost|True|240/240|1.599|3.443|0.886|0.305|0.450|
|main-t16-local-cost-basic-home / 41001 / cost|True|240/240|2.746|5.544|2.275|0.394|0.000|
|main-t16-local-cost-minimal-outstanding / 41001 / cost|True|240/240|1.689|3.352|0.857|0.280|0.458|
|main-t16-local-cost-progress-queue / 41001 / cost|True|240/240|2.221|4.749|1.610|0.509|0.475|
|main-t16-local-cost-basic-outstanding / 41001 / cost|True|240/240|1.637|3.181|0.880|0.279|0.471|
|main-t16-local-cost-minimal-remaining / 41001 / cost|True|240/240|2.220|4.476|1.618|0.516|0.500|
|main-t16-local-cost-minimal-queue-home / 41001 / cost|True|240/240|2.750|5.566|2.265|0.392|0.000|
|main-t16-local-cost-off-home / 41001 / cost|True|240/240|2.750|5.568|2.264|0.395|0.000|
|main-t16-local-cost-progress-home / 41001 / cost|True|240/240|3.951|7.937|3.047|0.711|0.000|
|main-t16-local-cost-minimal-remaining-home / 41002 / cost|True|240/240|3.722|7.294|2.877|0.659|0.000|
|main-t16-local-cost-minimal-outstanding-home / 41002 / cost|True|240/240|2.705|5.357|2.243|0.380|0.000|
|main-t16-local-cost-off-home / 41002 / cost|True|240/240|3.763|18.382|3.203|0.462|0.000|
|main-t16-local-cost-minimal-outstanding / 41002 / cost|True|240/240|1.529|3.023|0.737|0.257|0.492|
|main-t16-local-cost-progress-outstanding / 41002 / cost|True|240/240|2.153|4.073|1.572|0.490|0.500|
|main-t16-local-cost-minimal-remaining / 41002 / cost|True|240/240|2.152|4.085|1.572|0.495|0.500|
|main-t16-local-cost-basic-outstanding / 41002 / cost|True|240/240|1.636|3.192|0.912|0.253|0.450|
|main-t16-local-cost-minimal-queue / 41002 / cost|True|240/240|1.509|2.994|0.771|0.271|0.471|
|main-t16-local-cost-progress-queue / 41002 / cost|True|240/240|2.186|4.368|1.602|0.501|0.475|
|main-t16-local-cost-minimal-queue-home / 41002 / cost|True|240/240|2.701|5.341|2.149|0.365|0.000|
|main-t16-local-cost-basic-queue / 41002 / cost|True|240/240|1.580|3.057|0.844|0.270|0.458|
|main-t16-local-cost-basic-home / 41002 / cost|True|240/240|2.705|5.375|2.228|0.372|0.000|
|main-t16-local-cost-progress-home / 41002 / cost|True|240/240|3.790|7.417|2.976|0.665|0.000|
|main-t16-local-cost-progress-remaining / 41002 / cost|True|240/240|2.149|4.109|1.571|0.494|0.500|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
|main-t16-local-cost-basic-outstanding / cost|3/0|-1.113|-2.325|NA|descriptive_only|
|main-t16-local-cost-basic-queue / cost|3/0|-1.157|-2.242|NA|descriptive_only|
|main-t16-local-cost-minimal-outstanding / cost|3/0|-1.134|-2.275|NA|descriptive_only|
|main-t16-local-cost-minimal-queue / cost|3/0|-1.161|-2.281|NA|descriptive_only|
|main-t16-local-cost-minimal-remaining / cost|3/0|-1.690|-3.488|NA|descriptive_only|
|main-t16-local-cost-progress-outstanding / cost|3/0|-1.677|-3.376|NA|descriptive_only|
|main-t16-local-cost-progress-queue / cost|3/0|-1.668|-3.083|NA|descriptive_only|
|main-t16-local-cost-progress-remaining / cost|3/0|-1.684|-3.375|NA|descriptive_only|

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|
|main-t16-local-cost-basic-home|3|0.003|-0.356|-4.329|
|main-t16-local-cost-minimal-outstanding-home|3|0.003|-0.352|-4.348|
|main-t16-local-cost-minimal-queue-home|3|0.003|-0.356|-4.339|
|main-t16-local-cost-minimal-remaining-home|3|0.096|0.792|-2.040|
|main-t16-local-cost-progress-home|3|0.095|0.780|-2.175|

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
