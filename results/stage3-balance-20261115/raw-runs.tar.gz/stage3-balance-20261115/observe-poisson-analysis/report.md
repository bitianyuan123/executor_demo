# 阶段3：指标质量与阈值均衡

读取 6 轮，文件缺失/损坏等排除 0 条。原始 CSV 保留在各运行目录；本报告不重新解释失败为性能收益。

## 逐轮原始摘要

|case / seed / split|valid|完成/计划|planned均值 ms|planned p99 ms|W均值 ms|X均值 ms|spill|
|---|---|---:|---:|---:|---:|---:|---:|
|negative-t16-spread-home / 11000 / observe|True|420/420|371.976|910.167|99.001|271.088|0.000|
|negative-t16-smooth-home / 11000 / observe|True|336/336|36.280|114.651|0.291|35.765|0.000|
|negative-t16-smooth-home / 11001 / observe|True|311/311|32.901|90.868|0.234|32.469|0.000|
|negative-t16-spread-home / 11001 / observe|True|200/200|242.609|432.309|37.359|203.136|0.000|
|negative-t16-smooth-home / 11002 / observe|True|311/311|32.565|110.486|0.259|32.137|0.000|
|negative-t16-spread-home / 11002 / observe|True|340/340|384.176|760.171|109.451|273.321|0.000|

## 同种子配对收益

下表为候选减home的逐轮差值再取均值；负值表示时延下降。p99没有跨轮合并。

|case / split|有效/无效对|planned均值差 ms|planned p99差 ms|95% CI（p99差）|说明|
|---|---:|---:|---:|---|---|
没有可比较的routing候选；观测阶段不产生均衡收益结论。

## 留出整轮的指标预测

下表每行固定配置、指标、目标和模型，数值为留出seed各折等权均值；所有折明细见prediction.csv。MAE越小越好，p99 pinball越小越好，coverage需结合0.99目标和尾样本量判断。buckets.csv边界来自训练seed，p99及LOW_TAIL以独立burst数伴随报告。

|配置 / 指标|目标|模型|折数|mean MAE ms|p99 pinball ms|p99 coverage|相对自身预算基线MAE减少 ms|
|---|---|---|---:|---:|---:|---:|---:|
|2715f859531f / burst_context_remaining|callback_ms|burst_context_remaining|3|85.314|2.518|0.9895|-22.885|
|2715f859531f / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|65.045|1.457|0.9734|-2.616|
|2715f859531f / burst_context_remaining|latency_ms|burst_context_remaining|3|135.734|6.301|0.9871|-12.834|
|2715f859531f / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|120.891|6.024|0.9767|2.008|
|2715f859531f / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|135.716|6.283|0.9871|-12.852|
|2715f859531f / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|120.960|6.004|0.9767|1.904|
|2715f859531f / burst_context_remaining|wait_ms|burst_context_remaining|3|75.221|4.092|0.9913|8.832|
|2715f859531f / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|75.431|4.695|0.9775|8.623|
|2715f859531f / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|74.306|2.238|0.9878|-11.876|
|2715f859531f / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|50.308|1.197|0.9709|12.121|
|2715f859531f / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|76.013|3.809|0.9772|46.887|
|2715f859531f / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|63.509|3.879|0.9630|59.390|
|2715f859531f / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|76.170|3.738|0.9788|46.693|
|2715f859531f / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|63.604|3.891|0.9636|59.260|
|2715f859531f / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|30.849|1.095|0.9851|53.204|
|2715f859531f / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|39.643|1.968|0.9710|44.410|
|2715f859531f / queue|callback_ms|queue|3|85.546|2.603|0.9791|-23.117|
|2715f859531f / queue|callback_ms|queue+own_budget_oracle|3|64.634|1.335|0.9713|-2.205|
|2715f859531f / queue|latency_ms|queue|3|110.448|4.248|0.9726|12.451|
|2715f859531f / queue|latency_ms|queue+own_budget_oracle|3|102.404|4.216|0.9684|20.495|
|2715f859531f / queue|planned_latency_ms|queue|3|110.543|4.244|0.9734|12.321|
|2715f859531f / queue|planned_latency_ms|queue+own_budget_oracle|3|102.543|4.208|0.9684|20.321|
|2715f859531f / queue|wait_ms|queue|3|43.474|1.659|0.9859|40.579|
|2715f859531f / queue|wait_ms|queue+own_budget_oracle|3|51.715|2.623|0.9723|32.338|
|2715f859531f / queue_per_capacity|callback_ms|queue_per_capacity|3|85.546|2.603|0.9791|-23.117|
|2715f859531f / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|64.634|1.335|0.9713|-2.205|
|2715f859531f / queue_per_capacity|latency_ms|queue_per_capacity|3|110.448|4.248|0.9726|12.451|
|2715f859531f / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|102.404|4.216|0.9684|20.495|
|2715f859531f / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|110.543|4.244|0.9734|12.321|
|2715f859531f / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|102.543|4.208|0.9684|20.321|
|2715f859531f / queue_per_capacity|wait_ms|queue_per_capacity|3|43.474|1.659|0.9859|40.579|
|2715f859531f / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|51.715|2.623|0.9723|32.338|
|2715f859531f / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|77.450|2.542|0.9840|-15.021|
|2715f859531f / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|54.120|1.228|0.9775|8.309|
|2715f859531f / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|83.775|3.756|0.9767|39.125|
|2715f859531f / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|69.552|3.589|0.9669|53.347|
|2715f859531f / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|83.346|3.750|0.9767|39.517|
|2715f859531f / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|68.902|3.519|0.9685|53.962|
|2715f859531f / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|22.344|0.901|0.9852|61.709|
|2715f859531f / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|31.789|1.687|0.9736|52.264|
|2715f859531f / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|74.306|2.238|0.9878|-11.876|
|2715f859531f / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|50.308|1.197|0.9709|12.121|
|2715f859531f / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|76.013|3.809|0.9772|46.887|
|2715f859531f / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|63.509|3.879|0.9630|59.390|
|2715f859531f / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|76.170|3.738|0.9788|46.693|
|2715f859531f / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|63.604|3.891|0.9636|59.260|
|2715f859531f / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|30.849|1.095|0.9851|53.204|
|2715f859531f / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|39.643|1.968|0.9710|44.410|
|d3a98bb93fe2 / burst_context_remaining|callback_ms|burst_context_remaining|3|15.629|0.886|0.9858|-2.455|
|d3a98bb93fe2 / burst_context_remaining|callback_ms|burst_context_remaining+own_budget_oracle|3|13.420|0.745|0.9849|-0.245|
|d3a98bb93fe2 / burst_context_remaining|latency_ms|burst_context_remaining|3|15.836|0.886|0.9868|-2.399|
|d3a98bb93fe2 / burst_context_remaining|latency_ms|burst_context_remaining+own_budget_oracle|3|13.676|0.757|0.9847|-0.239|
|d3a98bb93fe2 / burst_context_remaining|planned_latency_ms|burst_context_remaining|3|15.950|0.886|0.9868|-2.372|
|d3a98bb93fe2 / burst_context_remaining|planned_latency_ms|burst_context_remaining+own_budget_oracle|3|13.815|0.765|0.9847|-0.237|
|d3a98bb93fe2 / burst_context_remaining|wait_ms|burst_context_remaining|3|0.437|0.042|0.9897|-0.002|
|d3a98bb93fe2 / burst_context_remaining|wait_ms|burst_context_remaining+own_budget_oracle|3|0.437|0.043|0.9896|-0.002|
|d3a98bb93fe2 / outstanding_per_capacity|callback_ms|outstanding_per_capacity|3|12.308|0.650|0.9877|0.867|
|d3a98bb93fe2 / outstanding_per_capacity|callback_ms|outstanding_per_capacity+own_budget_oracle|3|9.445|0.587|0.9827|3.730|
|d3a98bb93fe2 / outstanding_per_capacity|latency_ms|outstanding_per_capacity|3|12.314|0.650|0.9866|1.124|
|d3a98bb93fe2 / outstanding_per_capacity|latency_ms|outstanding_per_capacity+own_budget_oracle|3|9.563|0.601|0.9817|3.875|
|d3a98bb93fe2 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity|3|12.319|0.653|0.9866|1.259|
|d3a98bb93fe2 / outstanding_per_capacity|planned_latency_ms|outstanding_per_capacity+own_budget_oracle|3|9.648|0.603|0.9817|3.930|
|d3a98bb93fe2 / outstanding_per_capacity|wait_ms|outstanding_per_capacity|3|0.276|0.013|0.9862|0.159|
|d3a98bb93fe2 / outstanding_per_capacity|wait_ms|outstanding_per_capacity+own_budget_oracle|3|0.372|0.022|0.9894|0.063|
|d3a98bb93fe2 / queue|callback_ms|queue|3|15.629|0.886|0.9858|-2.455|
|d3a98bb93fe2 / queue|callback_ms|queue+own_budget_oracle|3|13.420|0.745|0.9849|-0.245|
|d3a98bb93fe2 / queue|latency_ms|queue|3|15.836|0.886|0.9868|-2.399|
|d3a98bb93fe2 / queue|latency_ms|queue+own_budget_oracle|3|13.676|0.757|0.9847|-0.239|
|d3a98bb93fe2 / queue|planned_latency_ms|queue|3|15.950|0.886|0.9868|-2.372|
|d3a98bb93fe2 / queue|planned_latency_ms|queue+own_budget_oracle|3|13.815|0.765|0.9847|-0.237|
|d3a98bb93fe2 / queue|wait_ms|queue|3|0.437|0.042|0.9897|-0.002|
|d3a98bb93fe2 / queue|wait_ms|queue+own_budget_oracle|3|0.437|0.043|0.9896|-0.002|
|d3a98bb93fe2 / queue_per_capacity|callback_ms|queue_per_capacity|3|15.629|0.886|0.9858|-2.455|
|d3a98bb93fe2 / queue_per_capacity|callback_ms|queue_per_capacity+own_budget_oracle|3|13.420|0.745|0.9849|-0.245|
|d3a98bb93fe2 / queue_per_capacity|latency_ms|queue_per_capacity|3|15.836|0.886|0.9868|-2.399|
|d3a98bb93fe2 / queue_per_capacity|latency_ms|queue_per_capacity+own_budget_oracle|3|13.676|0.757|0.9847|-0.239|
|d3a98bb93fe2 / queue_per_capacity|planned_latency_ms|queue_per_capacity|3|15.950|0.886|0.9868|-2.372|
|d3a98bb93fe2 / queue_per_capacity|planned_latency_ms|queue_per_capacity+own_budget_oracle|3|13.815|0.765|0.9847|-0.237|
|d3a98bb93fe2 / queue_per_capacity|wait_ms|queue_per_capacity|3|0.437|0.042|0.9897|-0.002|
|d3a98bb93fe2 / queue_per_capacity|wait_ms|queue_per_capacity+own_budget_oracle|3|0.437|0.043|0.9896|-0.002|
|d3a98bb93fe2 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity|3|12.035|0.697|0.9856|1.140|
|d3a98bb93fe2 / remaining_ms_per_capacity|callback_ms|remaining_ms_per_capacity+own_budget_oracle|3|9.377|0.667|0.9817|3.797|
|d3a98bb93fe2 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity|3|12.034|0.687|0.9876|1.404|
|d3a98bb93fe2 / remaining_ms_per_capacity|latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|9.462|0.679|0.9807|3.976|
|d3a98bb93fe2 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity|3|12.045|0.689|0.9876|1.533|
|d3a98bb93fe2 / remaining_ms_per_capacity|planned_latency_ms|remaining_ms_per_capacity+own_budget_oracle|3|9.517|0.684|0.9807|4.061|
|d3a98bb93fe2 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity|3|0.285|0.021|0.9905|0.150|
|d3a98bb93fe2 / remaining_ms_per_capacity|wait_ms|remaining_ms_per_capacity+own_budget_oracle|3|0.343|0.030|0.9801|0.092|
|d3a98bb93fe2 / work_ms_per_capacity|callback_ms|work_ms_per_capacity|3|12.308|0.650|0.9877|0.867|
|d3a98bb93fe2 / work_ms_per_capacity|callback_ms|work_ms_per_capacity+own_budget_oracle|3|9.445|0.587|0.9827|3.730|
|d3a98bb93fe2 / work_ms_per_capacity|latency_ms|work_ms_per_capacity|3|12.314|0.650|0.9866|1.124|
|d3a98bb93fe2 / work_ms_per_capacity|latency_ms|work_ms_per_capacity+own_budget_oracle|3|9.563|0.601|0.9817|3.875|
|d3a98bb93fe2 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity|3|12.319|0.653|0.9866|1.259|
|d3a98bb93fe2 / work_ms_per_capacity|planned_latency_ms|work_ms_per_capacity+own_budget_oracle|3|9.648|0.603|0.9817|3.930|
|d3a98bb93fe2 / work_ms_per_capacity|wait_ms|work_ms_per_capacity|3|0.276|0.013|0.9862|0.159|
|d3a98bb93fe2 / work_ms_per_capacity|wait_ms|work_ms_per_capacity+own_budget_oracle|3|0.372|0.022|0.9894|0.063|

## 固定工作量的观测成本

仅cost、home、iterations模式比较；相同seed/预算序列/资源，允许观测开关变化。routing收益表仍要求观测配置一致。

|case|有效对|CPU/completed task差 ms|planned均值差 ms|planned p99差 ms|
|---|---:|---:|---:|---:|

检测到work与outstanding仅为同一信号的常数缩放：d3a98bb93fe2, 2715f859531f。这不构成两个独立指标发现。

## 口径与限制

- Only routing=home observations enter metric-quality comparisons; selected pools after routing are selection-biased.
- Queue is Folly telemetry, not Linux runq. Outstanding includes callbacks already started but not completed.
- Capacity normalizes by configured min(threads, allowed logical CPUs) or an explicit override; it is not measured CPU throughput. Overlapping masks do not provide independent capacities.
- Work retains estimated full budgets until completion. Remaining subtracts periodically published progress; neither is exact future service demand. Synthetic exact estimates are oracle information.
- W=start-submit; X=end-start; L=end-submit; planned=end-planned. Submit precedes routing so W/L include routing. End precedes callback cleanup, so X excludes counter-cleanup tail. Their per-task sums hold, but quantiles do not add.
- A cohort is selected by planned arrival in [start,end); slow completions after end remain included. Rejections/cancellations/failures remain in the denominators.
- Inspect planned-time quartiles and submission lag for growing overload before treating a correlation as steady behavior.
- Correlation is per-task observational association, not a task-level p99, linear law or causal proof. Constant/missing metrics produce NA.
- Buckets and own-budget boundaries are fitted on training seeds only. Test units are entire unseen seeds; all tasks of a burst remain together.
- Prediction reports mean-predictor MAE plus conditional-p99 pinball loss and coverage. Predicted conditional p99 is not a whole-run p99. The own-budget baseline uses known synthetic CPU budgets and is labelled oracle.
- LOW_TAIL means fewer than 1000 tasks or 100 distinct bursts; p99 is still printed descriptively, not treated as a precise tail estimate.
- Pairing checks full planned task/burst/budget/estimate sequences plus resources and instrumentation. Invalid runs never contribute to a claimed gain.
- Benefits use per-run means and per-run p99 differences, never an average of per-second p99 or a pooled task bootstrap. At least 7 independent seeds are needed for a paired seed bootstrap CI.
- Constant estimates make work proportional to outstanding; this is a rescaled signal, not an independent discovery. Batch ordinal/context is synthetic workload information, not a production pool-load counter.
- Threshold curves expose all candidates. No automatic winner is declared. Tune/observe and evaluate seeds must be disjoint to avoid selection leakage.
- Process CPU/completed task includes process work during the entire run and drain; it is not worker-only CPU or the analysis-window CPU.
